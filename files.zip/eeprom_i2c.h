#ifndef EEPROM_24C32_H_
#define EEPROM_24C32_H_

#include <stdint.h>
#include "i2c_driver.h"

#define EEPROM_I2C_ADDR        0x50     // A2..A0 = 0 -> 0x50
#define EEPROM_PAGE_SIZE       32
#define EEPROM_SIZE_BYTES      4096     // 32 Kbit

/**
 * @brief Ghi 1 byte (co ACK polling cho den khi EEPROM ghi xong, co timeout)
 * @param mem_addr: dia chi o nho ben trong EEPROM can ghi
 * @param data: du lieu muon ghi
 * @retval I2C_OK, hoac ma loi (I2C_ERR_NACK: khong ket noi / I2C_ERR_TIMEOUT: ghi khong xong)
 */
i2c_status_t eeprom_write_data(uint16_t mem_addr, uint8_t data);

/**
 * @brief Doc 1 byte (random read, dung Repeated START)
 * @param mem_addr: dia chi o nho can doc
 * @param data: noi nhan du lieu (chi hop le khi tra ve I2C_OK)
 */
i2c_status_t eeprom_read_byte(uint16_t mem_addr, uint8_t *data);

#endif
