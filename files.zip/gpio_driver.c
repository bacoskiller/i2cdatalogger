#include "gpio_driver.h"


void gpio_init(GPIO_TypeDef *port, uint8_t pin, gpio_mode_t mode, gpio_cnf_t cnf)
{
	uint32_t pos = pin * 4;     // Moi pin chiem 4 bit
	volatile uint32_t *reg;     // Tro toi thanh ghi cau hinh (CRL/CRH)

	// Neu pin < 8 => CRL, nguoc lai CRH
	if (pin < 8) reg = &port->CRL;      // Cau hinh cho pin 0-7
	else {
		reg = &port->CRH;               // Cau hinh 8-15
		pos -= 32;                      // Dich vi tri vi CRH bat dau tu pin 8
	}
	// Xoa 4 bit cau hinh cu (dung 0xFUL de khong tran so nguyen co dau khi pos = 28)
	*reg &= ~(0xFUL << pos);
	// Ghi gia tri mode (2 bit thap), cnf (2 bit cao) vao vi tri pin
	*reg |= ((uint32_t)((mode & 0x03) | ((cnf & 0x03) << 2))) << pos;
}

void gpio_write(GPIO_TypeDef *port, uint8_t pin, uint8_t state)
{
	if (state)
	{
		port->BSRR = (1 << pin);    // Ghi 1 vao BSRR -> set pin
	}
	else
	{
		port->BRR = (1 << pin);     // Ghi 1 vao BRR  -> reset pin
	}
}

uint8_t gpio_read(GPIO_TypeDef *port, uint8_t pin)
{
	// Doc bit trong thanh ghi IDR, neu khac 0 -> tra ve 1, nguoc lai 0
	return (port->IDR & (1 << pin)) ? 1 : 0;
}

void gpio_toggle(GPIO_TypeDef *port, uint8_t pin)
{
	// XOR bit pin trong thanh ghi ODR de dao trang thai
	port->ODR ^= (1 << pin);
}

// EXTI5 (PA5) - chan OS cua LM75
void exti5_init(void)
{
    // 1. Bat clock cho AFIO (bat buoc de dung ngat ngoai)
    RCC->APB2ENR |= (1 << 0);

    // 2. Anh xa PA5 vao EXTI5
    // EXTI4 dung bit 0-3, EXTI5 dung bit 4-7 cua EXTICR2 (tuong duong EXTICR[1])
    AFIO->EXTICR[1] &= ~(0xF << 4); // 0000 = Port A

    // 3. Cau hinh co ngat
    EXTI->PR   = (1 << 5);          // Xoa co rac: GHI TRUC TIEP (PR la write-1-to-clear, khong dung |=)
    EXTI->IMR  |= (1 << 5);         // Mo cong ngat dong 5
    EXTI->FTSR |= (1 << 5);         // Ngat canh xuong (LM75 keo OS xuong 0)
    EXTI->RTSR &= ~(1 << 5);        // Tat ngat canh len

    // 4. Bat ngat tren NVIC
    NVIC_EnableIRQ(EXTI9_5_IRQn);
}
