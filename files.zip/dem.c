#include "stm32f10x.h"
#include "gpio_driver.h"
#include "lcd_i2c.h"
#include "delay.h"
#include "dem.h"
#include "eeprom_i2c.h"
#include "lm75.h"
#include "i2c_driver.h"
#include <stdint.h>
#include "log_eeprom.h"
#include "Sensor_mon.h"

volatile uint8_t  system_on            = 0;   // 0: OFF, 1: ON
volatile uint8_t  system_run           = 0;   // 0: khong chay, 1: RUN lien tuc
volatile int16_t  current_temp         = 0;   // Gia tri nhiet do tu LM75 (x10)
volatile uint8_t  eeprom_reset_request = 0;   // Yeu cau xoa log
volatile uint8_t  history_request      = 0;   // Yeu cau xem lich su (nut PA4)
volatile uint8_t  canh_bao_nhiet_do    = 0;   // Co tu ISR cua chan OS (trang thai that lay tu muc chan PA5)

#define EEPROM_WRITE_DELTA     5   // Chi ghi log khi lech >= 0.5 do C (don vi x10)
#define HISTORY_TIMEOUT_LOOPS  50  // 50 vong x ~200 ms = tu thoat che do xem sau ~10 s

/* ------------------------------------------------------------------ */
/*  DINH DANG NHIET DO                                                */
/* ------------------------------------------------------------------ */

// Doi so nguyen x10 thanh 6 ky tu: " 25.5", " -5.2", "-105.5". Dau tru nam sat chu so dau tien.
void format_temp_signed(int16_t value, char *buf)
{
    uint8_t  neg  = (value < 0);
    uint16_t v    = neg ? (uint16_t)(-(int32_t)value) : (uint16_t)value;
    uint16_t ip   = v / 10;       // phan nguyen
    uint8_t  frac = v % 10;       // 1 chu so thap phan
    uint8_t  pos  = 3;

    buf[0] = buf[1] = buf[2] = buf[3] = ' ';

    buf[pos--] = '0' + ip % 10;                       // dien tu phai sang trai
    if (ip >= 10)  buf[pos--] = '0' + (ip / 10)  % 10;
    if (ip >= 100) buf[pos--] = '0' + (ip / 100) % 10;
    if (neg)       buf[pos]   = '-';

    buf[4] = '.';
    buf[5] = '0' + frac;
    buf[6] = '\0';
}

/* ------------------------------------------------------------------ */
/*  NGAT NGOAI CAC NUT NHAN                                           */
/* ------------------------------------------------------------------ */

// EXTI0 (PA0) - Nut ON
void exti0_init(void)
{
    RCC->APB2ENR |= (1 << 0);          // bat clock AFIO truoc khi cau hinh EXTI
    AFIO->EXTICR[0] &= ~(0xF << 0);    // EXTI0 <- PA0
    EXTI->PR   = (1 << 0);             // xoa co rac (ghi 1 de xoa)
    EXTI->IMR  |= (1 << 0);
    EXTI->FTSR |= (1 << 0);            // canh xuong
    EXTI->RTSR &= ~(1 << 0);
    NVIC_EnableIRQ(EXTI0_IRQn);
}

void EXTI0_IRQHandler(void)
{
    if (EXTI->PR & (1 << 0)) {
        EXTI->PR = (1 << 0);
        system_on = 1;
    }
}

// EXTI1 (PA1) - Nut OFF / STOP
void exti1_init(void)
{
    RCC->APB2ENR |= (1 << 0);
    AFIO->EXTICR[0] &= ~(0xF << 4);
    EXTI->PR   = (1 << 1);
    EXTI->IMR  |= (1 << 1);
    EXTI->FTSR |= (1 << 1);
    EXTI->RTSR &= ~(1 << 1);
    NVIC_EnableIRQ(EXTI1_IRQn);
}

void EXTI1_IRQHandler(void)
{
    if (EXTI->PR & (1 << 1)) {
        EXTI->PR = (1 << 1);
        system_on  = 0;
        system_run = 0;
    }
}

// EXTI2 (PA2) - Nut RUN
void exti2_init(void)
{
    RCC->APB2ENR |= (1 << 0);
    AFIO->EXTICR[0] &= ~(0xF << 8);
    EXTI->PR   = (1 << 2);
    EXTI->IMR  |= (1 << 2);
    EXTI->FTSR |= (1 << 2);
    EXTI->RTSR &= ~(1 << 2);
    NVIC_EnableIRQ(EXTI2_IRQn);
}

void EXTI2_IRQHandler(void)
{
    if (EXTI->PR & (1 << 2)) {
        EXTI->PR = (1 << 2);
        if (system_on) {
            system_run = 1;
        }
    }
}

// EXTI3 (PA3) - Nut RST EEPROM
void exti3_init(void)
{
    RCC->APB2ENR |= (1 << 0);
    AFIO->EXTICR[0] &= ~(0xF << 12);
    EXTI->PR   = (1 << 3);
    EXTI->IMR  |= (1 << 3);
    EXTI->FTSR |= (1 << 3);
    EXTI->RTSR &= ~(1 << 3);
    NVIC_EnableIRQ(EXTI3_IRQn);
}

void EXTI3_IRQHandler(void)
{
    if (EXTI->PR & (1 << 3)) {
        EXTI->PR = (1 << 3);
        if (system_on) {
            eeprom_reset_request = 1;
        }
    }
}

// EXTI4 (PA4) - Nut XEM lich su
void exti4_init(void)
{
    RCC->APB2ENR |= (1 << 0);
    AFIO->EXTICR[1] &= ~(0xF << 0);    // EXTI4 <- PA4 (EXTICR2, bit 0-3)
    EXTI->PR   = (1 << 4);
    EXTI->IMR  |= (1 << 4);
    EXTI->FTSR |= (1 << 4);
    EXTI->RTSR &= ~(1 << 4);
    NVIC_EnableIRQ(EXTI4_IRQn);
}

void EXTI4_IRQHandler(void)
{
    if (EXTI->PR & (1 << 4)) {
        EXTI->PR = (1 << 4);
        if (system_on) {
            history_request = 1;
        }
    }
}

// EXTI5 (PA5) - Chan OS cua LM75 (canh xuong khi bat dau bao dong)
// Co nay chi la "su kien"; trang thai canh bao that duoc doc truc tiep tu muc chan PA5
// trong dem_sp() vi OS la tin hieu MUC (neu bat nguon khi da > Tos thi khong co canh nao).
void EXTI9_5_IRQHandler(void)
{
    if (EXTI->PR & (1 << 5))
    {
        EXTI->PR = (1 << 5);
        canh_bao_nhiet_do = 1;
    }
}

/* ------------------------------------------------------------------ */
/*  HIEN THI LCD                                                      */
/* ------------------------------------------------------------------ */

// Hien 1 dong 16 ky tu: nhan + gia tri nhiet do
static void lcd_show_temp_line(uint8_t row, const char *label, int16_t value)
{
    char buf[7];
    format_temp_signed(value, buf);

    set_cursor(0, row);
    lcd_send_string((char *)label);   // "TEMP:" / "MEMO:"
    set_cursor(5, row);
    lcd_send_string(buf);             // 6 ky tu
    lcd_send_string(" C   ");         // xoa phan du cua lan truoc
}

// Ghi so 0..999 thanh 3 ky tu
static void u3_to_str(uint16_t v, char *p)
{
    p[0] = '0' + (v / 100) % 10;
    p[1] = '0' + (v /  10) % 10;
    p[2] = '0' +  v        % 10;
}

// Dong 0: "LOG 003/017"   Dong 1: "TEMP:  25.5 C"
static void lcd_show_history(uint16_t idx, uint16_t total, int16_t value)
{
    char line[17] = "LOG 000/000     ";   // dung 16 ky tu
    u3_to_str(idx + 1, &line[4]);
    u3_to_str(total,   &line[8]);

    set_cursor(0, 0);
    lcd_send_string(line);
    lcd_show_temp_line(1, "TEMP:", value);
}

// Man hinh loi cam bien. Moi chuoi dung 16 ky tu. Khi OS dang keo thap thi dong 0 xen ke
// "CANH BAO NHIET!" de canh bao nhiet khong bi che mat boi man hinh loi.
static void lcd_show_fault(lm75_status_t f, uint8_t os_low, uint8_t blink)
{
    const char *msg;

    switch (f)
    {
        case LM75_ERR_NO_RESP: msg = "KHONG PHAN HOI  "; break;   // loi 1: khong bao gi
        case LM75_ERR_BUS:     msg = "LOI BUS I2C     "; break;   // loi 2: bao loi
        default:               msg = "SO LIEU SAI     "; break;   // loi 3: so sai
    }

    set_cursor(0, 0);
    lcd_send_string((blink && os_low) ? "CANH BAO NHIET! " : "LOI CAM BIEN    ");
    set_cursor(0, 1);
    lcd_send_string((char *)msg);
}

/* ------------------------------------------------------------------ */
/*  MAY TRANG THAI CHINH                                              */
/* ------------------------------------------------------------------ */

void dem_sp(void)
{
    static uint8_t  inited       = 0;
    static uint8_t  prev_state   = 0xFF;   // trang thai ON/OFF truoc do
    static uint8_t  prev_alarm   = 0xFF;   // 0: binh thuong, 1: bao dong nhiet, 2: loi cam bien
    static uint8_t  blink_phase  = 0;
    static int16_t  saved_temp   = 0;      // gia tri moi nhat trong log (hien o MEMO)

    static uint8_t  view_mode    = 0;      // 0: truc tiep, 1: xem lich su
    static uint16_t view_idx     = 0;      // 0 = moi nhat
    static uint16_t view_timeout = 0;

    // ---------- 1. KHOI TAO 1 LAN ----------
    if (!inited)
    {
        log_init();                         // quet EEPROM tim ban ghi moi nhat
        saved_temp   = log_last_temp();
        current_temp = saved_temp;
        inited = 1;
    }

    // ---------- 2. XU LY CHUYEN TRANG THAI ON/OFF ----------
    uint8_t state = system_on;

    if (state != prev_state)
    {
        if (state)
        {
            lcd_display_on();
            lcd_clear();
            set_cursor(0, 0);
            lcd_send_string(" LM75 DATALOGGER");
            delay(1000);
            lcd_clear();
            sensor_mon_reset();             // moi lan bat: cau hinh va giam sat lai cam bien
        }
        else
        {
            lcd_clear();
            lcd_display_off();
        }
        prev_state = state;
        prev_alarm = 0xFF;                  // ep ve lai giao dien
        view_mode  = 0;
    }

    if (!state)
    {
        system_run           = 0;
        eeprom_reset_request = 0;
        canh_bao_nhiet_do    = 0;
        history_request      = 0;
        view_mode            = 0;
        return;
    }

    uint8_t os_low = (gpio_read(GPIOA, 5) == 0);   // nguon su that cua canh bao nhiet

    // ---------- 3. XOA LOG (PA3) ----------
    if (eeprom_reset_request)
    {
        eeprom_reset_request = 0;
        system_run   = 0;
        current_temp = 0;
        view_mode    = 0;
        prev_alarm   = 0xFF;

        if (log_count() == 0 || log_clear() == I2C_OK) saved_temp = 0;
    }

    // ---------- 4. NUT XEM (PA4) ----------
    if (history_request)
    {
        history_request = 0;

        if (log_count() == 0)
        {
            lcd_clear();
            set_cursor(0, 0);
            lcd_send_string("CHUA CO DU LIEU");
            delay(1000);
            lcd_clear();
            view_mode  = 0;
            prev_alarm = 0xFF;
        }
        else if (!view_mode)                // bam lan dau: vao che do xem, hien moi nhat
        {
            view_mode    = 1;
            view_idx     = 0;
            view_timeout = 0;
        }
        else                                // bam tiep: lui ve ban ghi cu hon
        {
            view_idx++;
            view_timeout = 0;
            if (view_idx >= log_count())    // het du lieu -> quay ve man hinh truc tiep
            {
                view_mode  = 0;
                prev_alarm = 0xFF;
            }
        }
    }

    // Canh bao nhiet luon duoc uu tien hon man hinh xem lich su
    if (view_mode && os_low)
    {
        view_mode  = 0;
        prev_alarm = 0xFF;
    }

    // ---------- 5. CAM BIEN: CAU HINH / DOC / GIAM SAT LOI ----------
    {
        int16_t t   = 0;
        uint8_t got = sensor_mon_service((uint8_t)(system_run && !view_mode), os_low, &t);

        // Chi nhan mau khi dang RUN, khong con loi, va mau da qua moi kiem tra.
        // Mau loi KHONG BAO GIO duoc ghi vao log.
        if (got && system_run && !view_mode && sensor_mon_fault() == LM75_OK)
        {
            current_temp = t;

            int32_t diff = (int32_t)current_temp - (int32_t)saved_temp;
            if (diff < 0) diff = -diff;

            if (diff >= EEPROM_WRITE_DELTA)          // chi ghi khi lech >= 0.5 do C
            {
                if (log_append(current_temp) == I2C_OK) saved_temp = current_temp;
            }
        }
    }

    // ---------- 6. HIEN THI (uu tien: xem lich su > loi cam bien > bao dong > binh thuong) ----------
    canh_bao_nhiet_do = 0;

    if (view_mode)
    {
        // ===== XEM LICH SU =====
        int16_t v = 0;
        log_get(view_idx, &v);
        lcd_show_history(view_idx, log_count(), v);

        if (++view_timeout >= HISTORY_TIMEOUT_LOOPS)
        {
            view_mode  = 0;
            prev_alarm = 0xFF;
        }
        delay(200);
    }
    else if (sensor_mon_fault() != LM75_OK)
    {
        // ===== LOI CAM BIEN =====
        // Cam bien chet se tha chan OS len cao -> neu chi nhin OS se tuong "binh thuong".
        // Vi vay man hinh loi phai duoc uu tien hon man hinh binh thuong.
        if (prev_alarm != 2)
        {
            lcd_clear();
            prev_alarm  = 2;
            blink_phase = 0;
        }

        lcd_show_fault(sensor_mon_fault(), os_low, blink_phase);
        blink_phase ^= 1;
        delay(400);
    }
    else if (os_low)
    {
        // ===== BAO DONG NHIET: LM75 dang keo OS xuong 0 =====
        if (prev_alarm != 1)
        {
            lcd_clear();
            prev_alarm  = 1;
            blink_phase = 0;
        }

        if (blink_phase == 0)
        {
            set_cursor(0, 0);
            lcd_send_string("CANH BAO NHIET!");
            lcd_show_temp_line(1, "T:", current_temp);
        }
        else
        {
            lcd_clear();                    // chop tat
        }

        blink_phase ^= 1;
        delay(400);
    }
    else
    {
        // ===== BINH THUONG =====
        if (prev_alarm != 0)
        {
            lcd_clear();
            prev_alarm = 0;
        }

        lcd_show_temp_line(0, "TEMP:", current_temp);
        lcd_show_temp_line(1, "MEMO:", saved_temp);

        delay(200);
    }
}
