#include "Sensor_mon.h"

static lm75_status_t fault      = LM75_OK;
static uint8_t       configured = 0;   // da ghi + xac minh Tos/Thyst chua
static uint8_t       fail_cnt   = 0;
static uint8_t       ok_cnt     = 0;

void sensor_mon_reset(void)
{
    fault      = LM75_OK;
    configured = 0;
    fail_cnt   = 0;
    ok_cnt     = 0;
    LM75_ResetFilter();
}

lm75_status_t sensor_mon_fault(void)
{
    return fault;
}

// Chan OS phai khop voi nhiet do vua doc (comparator, active-low, co tre):
//   t >= Tos + 1 C   -> OS phai thap     |   t <= Thyst - 1 C -> OS phai cao
static uint8_t os_matches(int16_t t, uint8_t os_low)
{
#if OS_CROSSCHECK
    if (t >= (TEMP_TOS_C   * 10 + OS_MARGIN_X10) && !os_low) return 0;
    if (t <= (TEMP_THYST_C * 10 - OS_MARGIN_X10) &&  os_low) return 0;
#else
    (void)t; (void)os_low;
#endif
    return 1;
}

uint8_t sensor_mon_service(uint8_t want_sample, uint8_t os_low, int16_t *t)
{
    lm75_status_t st;
    uint8_t got = 0;

    if (!configured)
    {
        // Chua cau hinh (moi bat, hoac vua bi loi): ghi lai Tos/Thyst.
        // Can thiet vi cam bien mat nguon se ve mac dinh Tos = 80 C, Thyst = 75 C.
        st = LM75_Init(TEMP_TOS_C, TEMP_THYST_C);
        if (st == LM75_OK)
        {
            configured = 1;
            LM75_ResetFilter();
        }
    }
    else if (want_sample || fault != LM75_OK)
    {
        st = LM75_ReadTemp(t);
        if (st == LM75_OK && !os_matches(*t, os_low)) st = LM75_ERR_BAD_VALUE;
        if (st == LM75_OK) got = 1;
    }
    else
    {
        return 0;                        // khong can lam gi
    }

    if (st == LM75_OK)
    {
        fail_cnt = 0;
        if (fault != LM75_OK && got && ++ok_cnt >= SENSOR_RECOVER_OK)
        {
            fault  = LM75_OK;            // hoi phuc
            ok_cnt = 0;
        }
    }
    else
    {
        ok_cnt = 0;
        if (fail_cnt < 255) fail_cnt++;

        if (fail_cnt >= SENSOR_FAIL_LIMIT)
        {
            if (fault == LM75_OK) LM75_ResetFilter();   // lan doc dau tien sau loi khong bi loc nhay
            fault      = st;                            // luon cap nhat ma loi moi nhat
            configured = 0;                             // hoi phuc xong phai cau hinh lai
        }
    }
    return got;
}