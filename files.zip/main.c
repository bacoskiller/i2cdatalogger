#include "gpio_driver.h"
#include "lcd_i2c.h"
#include "i2c_driver.h"
#include "delay.h"
#include "dem.h"
#include "eeprom_i2c.h"

int main(void)
{
    SystemInit();

    // Bat clock cho TIM1 (dung cho delay)
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    // Khoi tao I2C (dung chung cho LM75, EEPROM va LCD)
    i2c_init();

    // Khoi tao LCD
    lcd_init();

    // Bat clock GPIOA va GPIOB
    gpio_enable_clock(GPIOA);
    gpio_enable_clock(GPIOB);

    // PA0..PA5 input pull-up cho cac nut nhan va chan OS
    // (bit ODR = 1 de chon pull-up; neu bo qua thi mac dinh la pull-down)
    gpio_init(GPIOA, 0, GPIO_MODE_INPUT, GPIO_CNF_PU_PD);   // START
    GPIOA->ODR |= (1 << 0);

    gpio_init(GPIOA, 1, GPIO_MODE_INPUT, GPIO_CNF_PU_PD);   // STOP
    GPIOA->ODR |= (1 << 1);

    gpio_init(GPIOA, 2, GPIO_MODE_INPUT, GPIO_CNF_PU_PD);   // READ (RUN)
    GPIOA->ODR |= (1 << 2);

    gpio_init(GPIOA, 3, GPIO_MODE_INPUT, GPIO_CNF_PU_PD);   // XOA EEPROM
    GPIOA->ODR |= (1 << 3);

    gpio_init(GPIOA, 4, GPIO_MODE_INPUT, GPIO_CNF_PU_PD);   // XEM lich su
    GPIOA->ODR |= (1 << 4);

    gpio_init(GPIOA, 5, GPIO_MODE_INPUT, GPIO_CNF_PU_PD);   // OS cua LM75
    GPIOA->ODR |= (1 << 5);

    // Khoi tao ngat ngoai
    exti0_init();
    exti1_init();
    exti2_init();
    exti3_init();
    exti4_init();
    exti5_init();
    __enable_irq();

    // Vong lap chinh
    while (1) {
        dem_sp();
    }
}
