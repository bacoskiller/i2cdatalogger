#include "stm32f10x.h"
#include "stdint.h"
#include "i2c_driver.h"
#include "gpio_driver.h"

/* So vong lap toi da cho moi lan cho co.
 * 1 byte I2C @100kHz ~ 90us = ~6500 chu ky CPU; 100000 vong lap >> thoi gian do
 * nhung van chi vai ms den chuc ms nen khong lam treo he thong. */
#define I2C_TIMEOUT_LOOPS   100000UL

#define I2C_CHECK(expr)  do { i2c_status_t _s = (expr); if (_s != I2C_OK) return _s; } while (0)

/* ------------------------------------------------------------------ */
/*  Ham noi bo                                                        */
/* ------------------------------------------------------------------ */

// Cau hinh phan cung I2C1 (100 kHz, APB1 = 36 MHz)
static void i2c_hw_init(void)
{
    I2C1->CR1 = I2C_CR1_SWRST;   // Reset I2C
    I2C1->CR1 = 0;               // Nha reset

    I2C1->CR2   = 36;            // Tan so APB1 = 36 MHz
    I2C1->CCR   = 180;           // 100 kHz, duty 50%: 5000ns / 27.78ns = 180
    I2C1->TRISE = 37;            // 1000ns / 27.78ns + 1 = 37
    I2C1->CR1  |= I2C_CR1_PE;    // Bat I2C1
}

// Tre ngan cho bit-bang khi khoi phuc bus (cham hon 100 kHz nen an toan)
static void bb_delay(void)
{
    for (volatile uint32_t i = 0; i < 300; i++);
}

/* Cho 1 trong cac co SR1 trong ok_mask.
 * Thoat som neu gap loi: AF (NACK), BERR/ARLO (loi bus), hoac het thoi gian. */
static i2c_status_t i2c_wait(uint32_t ok_mask)
{
    uint32_t timeout = I2C_TIMEOUT_LOOPS;
    uint32_t sr1;

    while (1)
    {
        sr1 = I2C1->SR1;

        if (sr1 & ok_mask)                          return I2C_OK;
        if (sr1 & I2C_SR1_AF)                       return I2C_ERR_NACK;
        if (sr1 & (I2C_SR1_BERR | I2C_SR1_ARLO))    return I2C_ERR_BUS;
        if (--timeout == 0)                         return I2C_ERR_TIMEOUT;
    }
}

/* Xu ly khi co loi: dua bus ve trang thai an toan roi tra lai ma loi. */
static i2c_status_t i2c_fail(i2c_status_t status)
{
    if (status == I2C_ERR_NACK)
    {
        I2C1->SR1 &= ~I2C_SR1_AF;          // xoa co AF
        I2C1->CR1 |= I2C_CR1_STOP;         // giai phong bus
    }
    else
    {
        // Timeout hoac loi bus: khoi phuc han
        i2c_recover();
    }
    return status;
}

/* ------------------------------------------------------------------ */
/*  API cong khai                                                     */
/* ------------------------------------------------------------------ */

void i2c_init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;   // clock I2C1
    gpio_enable_clock(GPIOB);             // clock port B
    RCC->APB2ENR |= RCC_APB2ENR_AFIOEN;   // clock AFIO

    // PB6 = SCL, PB7 = SDA: alternate function open-drain (bat buoc voi I2C)
    gpio_init(GPIOB, 6, GPIO_MODE_OUTPUT_50M, GPIO_CNF_AF_OD);
    gpio_init(GPIOB, 7, GPIO_MODE_OUTPUT_50M, GPIO_CNF_AF_OD);

    i2c_hw_init();
}

/*
 * Khoi phuc bus khi bi ket (slave giu SDA thap do bi ngat giua chung, hoac BUSY treo):
 *  1. Tat I2C, chuyen PB6/PB7 sang GPIO open-drain
 *  2. Phat toi da 9 xung SCL de slave nha SDA
 *  3. Phat dieu kien STOP thu cong
 *  4. Tra chan ve AF va khoi tao lai I2C
 */
void i2c_recover(void)
{
    I2C1->CR1 &= ~I2C_CR1_PE;

    // PB6, PB7: GPIO output open-drain 50MHz (CNF=01, MODE=11 => 0x7)
    GPIOB->CRL = (GPIOB->CRL & ~(0xFFUL << 24)) | (0x77UL << 24);
    GPIOB->BSRR = (1U << 6) | (1U << 7);           // tha ca 2 len cao
    bb_delay();

    for (uint8_t i = 0; i < 9; i++)
    {
        if (GPIOB->IDR & (1U << 7)) break;         // SDA da duoc nha
        GPIOB->BRR  = (1U << 6); bb_delay();       // SCL thap
        GPIOB->BSRR = (1U << 6); bb_delay();       // SCL cao
    }

    // Dieu kien STOP: SDA thap -> SCL cao -> SDA cao
    GPIOB->BRR  = (1U << 7); bb_delay();
    GPIOB->BSRR = (1U << 6); bb_delay();
    GPIOB->BSRR = (1U << 7); bb_delay();

    // Tra ve chuc nang I2C
    gpio_init(GPIOB, 6, GPIO_MODE_OUTPUT_50M, GPIO_CNF_AF_OD);
    gpio_init(GPIOB, 7, GPIO_MODE_OUTPUT_50M, GPIO_CNF_AF_OD);

    i2c_hw_init();
}

// Cho bus ranh (BUSY = 0). Qua thoi gian thi khoi phuc bus va kiem tra lai.
i2c_status_t i2c_wait_bus_free(void)
{
    uint32_t timeout = I2C_TIMEOUT_LOOPS;

    while (I2C1->SR2 & I2C_SR2_BUSY)
    {
        if (--timeout == 0)
        {
            i2c_recover();
            return (I2C1->SR2 & I2C_SR2_BUSY) ? I2C_ERR_BUS : I2C_OK;
        }
    }
    return I2C_OK;
}

i2c_status_t i2c_start(uint8_t mode)
{
    if (mode == I2C_MODE_MASTER)
    {
        I2C1->CR1 |= I2C_CR1_START;                 // phat START
        i2c_status_t st = i2c_wait(I2C_SR1_SB);     // cho SB = 1
        if (st != I2C_OK) return i2c_fail(st);
    }
    else if (mode == I2C_MODE_SLAVE)
    {
        I2C1->CR1 |= I2C_CR1_ACK;                   // cho phep ACK
        i2c_status_t st = i2c_wait(I2C_SR1_ADDR);   // cho nhan dia chi
        if (st != I2C_OK) return i2c_fail(st);

        volatile uint32_t temp = I2C1->SR1;         // doc SR1 roi SR2 de xoa ADDR
        temp = I2C1->SR2;
        (void)temp;
    }
    return I2C_OK;
}

void i2c_stop(void)
{
    I2C1->CR1 |= I2C_CR1_STOP;
}

i2c_status_t i2c_send_address(uint8_t address, uint8_t rw)
{
    I2C1->DR = (uint8_t)((address << 1) | (rw & 0x1));

    i2c_status_t st = i2c_wait(I2C_SR1_ADDR);       // ACK -> ADDR, NACK -> AF
    if (st != I2C_OK) return i2c_fail(st);

    volatile uint32_t temp = I2C1->SR1;             // doc SR1 roi SR2 de xoa ADDR
    temp = I2C1->SR2;
    (void)temp;
    return I2C_OK;
}

i2c_status_t i2c_write_data(uint8_t data)
{
    i2c_status_t st = i2c_wait(I2C_SR1_TXE);        // DR trong
    if (st != I2C_OK) return i2c_fail(st);

    I2C1->DR = data;

    st = i2c_wait(I2C_SR1_BTF);                     // da gui xong byte
    if (st != I2C_OK) return i2c_fail(st);

    return I2C_OK;
}

i2c_status_t i2c_write_byte(uint8_t slave_address, uint8_t data)
{
    I2C_CHECK(i2c_wait_bus_free());
    I2C_CHECK(i2c_start(I2C_MODE_MASTER));
    I2C_CHECK(i2c_send_address(slave_address, 0));
    I2C_CHECK(i2c_write_data(data));
    i2c_stop();
    return I2C_OK;
}

i2c_status_t i2c_write_mul_bytes(uint8_t slave_address, uint8_t *data, uint8_t length)
{
    I2C_CHECK(i2c_wait_bus_free());
    I2C_CHECK(i2c_start(I2C_MODE_MASTER));
    I2C_CHECK(i2c_send_address(slave_address, 0));

    for (uint8_t i = 0; i < length; i++)
    {
        I2C_CHECK(i2c_write_data(data[i]));         // TXE -> DR -> BTF
    }

    i2c_stop();
    return I2C_OK;
}

/* ------------------------------------------------------------------ */
/*  DOC (master receiver) - theo Reference Manual STM32F1             */
/*    N=1: xoa ACK -> xoa ADDR -> STOP -> cho RXNE -> doc DR          */
/*    N=2: ACK+POS truoc START -> xoa ADDR -> xoa ACK -> cho BTF      */
/*         -> STOP -> doc DR 2 lan                                    */
/* ------------------------------------------------------------------ */

/* Pha doc: START (hoac Repeated START) + SLA+R + nhan length byte (1..2) + STOP.
 * Moi lan cho deu co timeout; gap loi thi tra ma loi, khong treo. */
static i2c_status_t i2c_read_phase(uint8_t slave_address, uint8_t *data, uint8_t length)
{
    volatile uint32_t tmp;
    i2c_status_t st;

    if (length == 2) I2C1->CR1 |= (I2C_CR1_ACK | I2C_CR1_POS);
    else             I2C1->CR1 |=  I2C_CR1_ACK;

    I2C_CHECK(i2c_start(I2C_MODE_MASTER));

    I2C1->DR = (uint8_t)((slave_address << 1) | 1);      // SLA+R
    st = i2c_wait(I2C_SR1_ADDR);                         // ACK -> ADDR, NACK -> AF
    if (st != I2C_OK) return i2c_fail(st);

    if (length == 1)
    {
        I2C1->CR1 &= ~I2C_CR1_ACK;                       // NACK cho byte duy nhat
        tmp = I2C1->SR1; tmp = I2C1->SR2;                // xoa ADDR
        I2C1->CR1 |= I2C_CR1_STOP;

        st = i2c_wait(I2C_SR1_RXNE);
        if (st != I2C_OK) return i2c_fail(st);
        data[0] = (uint8_t)I2C1->DR;
    }
    else
    {
        tmp = I2C1->SR1; tmp = I2C1->SR2;                // xoa ADDR
        I2C1->CR1 &= ~I2C_CR1_ACK;                       // NACK cho byte thu 2 (POS = 1)

        st = i2c_wait(I2C_SR1_BTF);                      // byte 1 trong DR, byte 2 trong shift reg
        if (st != I2C_OK) return i2c_fail(st);

        I2C1->CR1 |= I2C_CR1_STOP;
        data[0] = (uint8_t)I2C1->DR;
        data[1] = (uint8_t)I2C1->DR;
    }
    (void)tmp;
    return I2C_OK;
}

// Tra ACK/POS ve trang thai mac dinh sau moi giao dich doc (ke ca khi loi)
static void i2c_read_restore(void)
{
    I2C1->CR1 &= ~I2C_CR1_POS;
    I2C1->CR1 |=  I2C_CR1_ACK;
}

i2c_status_t i2c_read_mul_bytes(uint8_t slave_address, uint8_t *data, uint8_t length)
{
    i2c_status_t st;

    if (length != 1 && length != 2) return I2C_ERR_BUS;  // chua ho tro do dai khac

    st = i2c_wait_bus_free();
    if (st == I2C_OK) st = i2c_read_phase(slave_address, data, length);

    i2c_read_restore();
    return st;
}

i2c_status_t i2c_write_read(uint8_t slave_address, const uint8_t *wdata, uint8_t wlen,
                            uint8_t *rdata, uint8_t rlen)
{
    i2c_status_t st;

    if (rlen != 1 && rlen != 2) return I2C_ERR_BUS;

    st = i2c_wait_bus_free();
    if (st == I2C_OK) st = i2c_start(I2C_MODE_MASTER);
    if (st == I2C_OK) st = i2c_send_address(slave_address, 0);

    for (uint8_t i = 0; st == I2C_OK && i < wlen; i++)
    {
        st = i2c_write_data(wdata[i]);
    }

    // Repeated START (khong STOP) roi doc
    if (st == I2C_OK) st = i2c_read_phase(slave_address, rdata, rlen);

    i2c_read_restore();
    return st;
}
