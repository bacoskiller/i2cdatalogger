#include "stm32f10x.h"
#include "lm75.h"
#include "delay.h"
#include "i2c_driver.h"

#define LM75_REG_TEMP    0x00
#define LM75_REG_THYST   0x02
#define LM75_REG_TOS     0x03

#define LM75_RETRY             3     // so lan thu lai moi giao dich I2C
#define LM75_MIN_X10         (-550)  // -55.0 C  (gioi han datasheet)
#define LM75_MAX_X10          1250   // +125.0 C
#define LM75_MAX_JUMP_X10      100   // nhay > 10.0 C giua 2 mau lien tiep bi nghi ngo
#define LM75_CAND_TOL_X10        5   // 2 mau "moi" lech <= 0.5 C coi la cung gia tri
#define LM75_JUMP_CONFIRM        3   // can 3 mau lien tiep giong nhau moi chap nhan buoc nhay

// Doi thanh 0 neu model cam bien (vd Proteus) khong thoa man kiem tra tuong ung
#define LM75_CHECK_UNUSED_BITS   1   // D4..D0 cua thanh ghi nhiet do phai bang 0
#define LM75_VERIFY_READBACK     1   // doc lai Tos/Thyst sau khi ghi

static int16_t last_good = 0;        // mau hop le gan nhat
static uint8_t have_last = 0;
static int16_t cand      = 0;        // gia tri "ung vien" khi gap buoc nhay
static uint8_t cand_cnt  = 0;

static int32_t absd(int32_t a, int32_t b)
{
    return (a > b) ? (a - b) : (b - a);
}

// Gom ma loi I2C thanh 2 nhom: khong phan hoi / loi bus
static lm75_status_t map_status(i2c_status_t s)
{
    switch (s)
    {
        case I2C_OK:      return LM75_OK;
        case I2C_ERR_BUS: return LM75_ERR_BUS;
        default:          return LM75_ERR_NO_RESP;   // NACK, TIMEOUT
    }
}

// Tro con tro thanh ghi roi doc 2 byte, thu lai toi da LM75_RETRY lan
static lm75_status_t lm75_read_reg16(uint8_t reg, uint16_t *val)
{
    uint8_t buf[2];
    i2c_status_t st = I2C_ERR_TIMEOUT;

    for (uint8_t n = 0; n < LM75_RETRY; n++)
    {
        st = i2c_write_byte(LM75_I2C_ADDR, reg);
        if (st == I2C_OK) st = i2c_read_mul_bytes(LM75_I2C_ADDR, buf, 2);
        if (st == I2C_OK)
        {
            *val = (uint16_t)(((uint16_t)buf[0] << 8) | buf[1]);
            return LM75_OK;
        }
        delay(2);
    }
    return map_status(st);
}

static lm75_status_t lm75_write_reg16(uint8_t reg, uint16_t val)
{
    uint8_t buf[3];
    i2c_status_t st = I2C_ERR_TIMEOUT;

    buf[0] = reg;
    buf[1] = (uint8_t)(val >> 8);
    buf[2] = (uint8_t)(val & 0xFF);

    for (uint8_t n = 0; n < LM75_RETRY; n++)
    {
        st = i2c_write_mul_bytes(LM75_I2C_ADDR, buf, 3);
        if (st == I2C_OK) return LM75_OK;
        delay(2);
    }
    return map_status(st);
}

lm75_status_t LM75_Init(uint8_t tos_c, uint8_t thyst_c)
{
    lm75_status_t st;
    uint16_t tos_val   = (uint16_t)((uint16_t)tos_c   << 8);   // vd 40 C -> 0x2800
    uint16_t thyst_val = (uint16_t)((uint16_t)thyst_c << 8);

    st = lm75_write_reg16(LM75_REG_TOS, tos_val);     if (st != LM75_OK) return st;
    st = lm75_write_reg16(LM75_REG_THYST, thyst_val); if (st != LM75_OK) return st;

#if LM75_VERIFY_READBACK
    {
        uint16_t rb;
        // chi 9 bit cao (D15..D7) co nghia
        st = lm75_read_reg16(LM75_REG_TOS, &rb);
        if (st != LM75_OK) return st;
        if ((rb & 0xFF80u) != (tos_val & 0xFF80u)) return LM75_ERR_BAD_VALUE;

        st = lm75_read_reg16(LM75_REG_THYST, &rb);
        if (st != LM75_OK) return st;
        if ((rb & 0xFF80u) != (thyst_val & 0xFF80u)) return LM75_ERR_BAD_VALUE;
    }
#endif
    return LM75_OK;
}

void LM75_ResetFilter(void)
{
    have_last = 0;
    cand_cnt  = 0;
}

lm75_status_t LM75_ReadTemp(int16_t *temp_x10)
{
    uint16_t raw;
    int32_t  t;
    lm75_status_t st = lm75_read_reg16(LM75_REG_TEMP, &raw);

    if (st != LM75_OK) return st;                       // loi 1 / loi 2

    // ---- Kiem tra "so sai" (loi 3) ----
#if LM75_CHECK_UNUSED_BITS
    // 0xFFFF (bus tha noi) -> raw>>5 = -1 -> -0.1 C: nhin hop le nhung thuc ra la rac.
    if (raw & 0x001F) return LM75_ERR_BAD_VALUE;
#endif

    t = (int32_t)((int16_t)raw >> 5) * 125 / 100;       // don vi 0.1 C

    if (t < LM75_MIN_X10 || t > LM75_MAX_X10) return LM75_ERR_BAD_VALUE;

    // Loc nhay: mau nhay vot so voi mau truoc phai lap lai on dinh moi duoc nhan
    if (have_last && absd(t, last_good) > LM75_MAX_JUMP_X10)
    {
        if (cand_cnt > 0 && absd(t, cand) <= LM75_CAND_TOL_X10) cand_cnt++;
        else { cand = (int16_t)t; cand_cnt = 1; }

        if (cand_cnt < LM75_JUMP_CONFIRM) return LM75_ERR_BAD_VALUE;
    }

    last_good = (int16_t)t;
    have_last = 1;
    cand_cnt  = 0;
    *temp_x10 = (int16_t)t;
    return LM75_OK;
}
