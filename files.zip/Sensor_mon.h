#ifndef SENSOR_MON_H
#define SENSOR_MON_H

#include <stdint.h>
#include "lm75.h"

#ifndef TEMP_TOS_C
#define TEMP_TOS_C       40          // nguong bao dong (do C)
#endif
#ifndef TEMP_THYST_C
#define TEMP_THYST_C     39          // nguong nha bao dong (do C)
#endif

#define SENSOR_FAIL_LIMIT   3        // loi lien tiep bao nhieu lan thi tuyen bo "co loi"
#define SENSOR_RECOVER_OK   2        // doc tot lien tiep bao nhieu lan thi coi la het loi
#define OS_CROSSCHECK       1        // doi chieu muc chan OS voi nhiet do (doi 0 neu model khong khop)
#define OS_MARGIN_X10       10       // du dia 1.0 C quanh Tos/Thyst

void          sensor_mon_reset(void);                     // goi khi bat he thong
lm75_status_t sensor_mon_fault(void);                     // LM75_OK = binh thuong
// Goi moi vong lap. want_sample=1 khi can doc nhiet do (che do RUN).
// Tra ve 1 neu vua co mau hop le (da ghi vao *t).
uint8_t       sensor_mon_service(uint8_t want_sample, uint8_t os_low, int16_t *t);

#endif
