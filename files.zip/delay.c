#include "stm32f10x.h"
#include "delay.h"

#define DELAY_CHUNK_MS  6000U   // 6000 ms * 10 tick = 60000 < 65536 (ARR 16-bit)

/*
 * Delay blocking bang TIM1.
 * PSC = 7199 => 72MHz / 7200 = 10kHz => 1 tick = 0.1 ms.
 * Ho tro toan bo dai uint16_t (0..65535 ms) bang cach chia thanh nhieu doan.
 */
void delay(uint16_t ms)
{
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;   // dam bao TIM1 co clock

    TIM1->CR1 &= ~TIM_CR1_CEN;            // dung timer neu dang chay
    TIM1->PSC  = 7199;

    while (ms)
    {
        uint16_t chunk = (ms > DELAY_CHUNK_MS) ? DELAY_CHUNK_MS : ms;
        ms -= chunk;

        TIM1->ARR = (uint16_t)(chunk * 10U - 1U);
        TIM1->EGR = TIM_EGR_UG;           // Ep update event: nap PSC/ARR vao shadow, CNT = 0
        TIM1->SR &= ~TIM_SR_UIF;          // xoa UIF do chinh UG vua gay ra
        TIM1->CR1 |= TIM_CR1_CEN;         // chay

        while (!(TIM1->SR & TIM_SR_UIF)); // cho tran

        TIM1->CR1 &= ~TIM_CR1_CEN;        // dung
    }
}
