#ifndef LOG_EEPROM_H
#define LOG_EEPROM_H

#include <stdint.h>
#include "i2c_driver.h"

void         log_init(void);                 // quet EEPROM, tim ban ghi moi nhat (goi luc khoi dong)
uint16_t     log_count(void);                // so ban ghi hop le hien co (0 neu EEPROM loi)
i2c_status_t log_append(int16_t temp_x10);   // them 1 ban ghi (ghi de ban ghi cu nhat khi day)
uint8_t      log_get(uint16_t back, int16_t *temp_x10); // back=0: moi nhat, 1: ke truoc... ; 1 neu hop le
int16_t      log_last_temp(void);            // gia tri moi nhat (0 neu rong)
i2c_status_t log_clear(void);                // xoa toan bo log (chi ghi 2 byte)

#endif
