#ifndef DEM_H_
#define DEM_H_

#include <stdint.h>

/**
 * @brief  May trang thai chinh cua datalogger (goi lien tuc trong while(1) cua main)
 *         - ON/OFF, RUN (do + ghi log), RESET log
 *         - XEM lai lich su nhiet do da luu
 *         - Canh bao nhiet (chan OS) va xu ly loi cam bien
 */
void dem_sp(void);

// Doi nhiet do x10 (vd 255) thanh chuoi 6 ky tu " 25.5" + '\0' (buf >= 7 byte)
void format_temp_signed(int16_t value, char *buf);

void exti0_init(void);          // PA0 - nut START (ON)
void EXTI0_IRQHandler(void);

void exti1_init(void);          // PA1 - nut STOP (OFF)
void EXTI1_IRQHandler(void);

void exti2_init(void);          // PA2 - nut READ (RUN)
void EXTI2_IRQHandler(void);

void exti3_init(void);          // PA3 - nut XOA EEPROM
void EXTI3_IRQHandler(void);

void exti4_init(void);          // PA4 - nut XEM lich su
void EXTI4_IRQHandler(void);

// EXTI5 (PA5 - chan OS cua LM75): exti5_init() nam trong gpio_driver.c,
// ISR EXTI9_5_IRQHandler nam trong dem.c

#endif
