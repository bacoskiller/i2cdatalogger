/* ------------------------------------------------------------------
 * Log nhiet do dang vong dem trong EEPROM 24C32A
 *
 * Ban ghi 4 byte:  [seq_hi][seq_lo][temp_hi][temp_lo]
 *   - seq   : so thu tu tang dan (16-bit, 0xFFFF = o trong)
 *   - temp  : nhiet do x10, co dau
 *
 * Vung nho (khong de len vung nao khac cua chuong trinh):
 *   LOG_HDR_ADDR : 2 byte "floor" - cac ban ghi co seq < floor coi nhu da xoa
 *   LOG_BASE     : LOG_SLOTS o x 4 byte  (0x0110 .. 0x050F)
 *
 * Neu EEPROM loi (khong ket noi): log_init() danh dau log "khong dung duoc"
 * (count = 0). log_append() se thu khoi tao lai moi lan goi, nen log tu hoat
 * dong tro lai khi EEPROM duoc noi lai.
 * ------------------------------------------------------------------ */
#include "stm32f10x.h"
#include "eeprom_i2c.h"
#include "log_eeprom.h"

#define LOG_HDR_ADDR   0x0100u
#define LOG_BASE       0x0110u
#define LOG_SLOTS      256u          // 256 x 4 = 1 KB
#define LOG_REC_SIZE   4u

static uint8_t       log_ok        = 0;   // 1: da quet EEPROM thanh cong
static i2c_status_t  log_err       = I2C_OK;
static uint16_t      log_floor     = 0;   // seq nho nhat con hop le
static uint16_t      log_next_slot = 0;   // o se ghi tiep theo
static uint16_t      log_next_seq  = 0;   // seq se gan cho ban ghi tiep theo
static uint16_t      log_cnt       = 0;   // so ban ghi hop le

static uint16_t slot_addr(uint16_t slot)
{
    return (uint16_t)(LOG_BASE + slot * LOG_REC_SIZE);
}

static i2c_status_t rd16(uint16_t addr, uint16_t *v)
{
    uint8_t h = 0, l = 0;
    i2c_status_t st;

    st = eeprom_read_byte(addr,     &h);  if (st != I2C_OK) return st;
    st = eeprom_read_byte(addr + 1, &l);  if (st != I2C_OK) return st;

    *v = (uint16_t)(((uint16_t)h << 8) | l);
    return I2C_OK;
}

static i2c_status_t wr16(uint16_t addr, uint16_t v)
{
    i2c_status_t st;

    st = eeprom_write_data(addr,     (uint8_t)(v >> 8));    if (st != I2C_OK) return st;
    st = eeprom_write_data(addr + 1, (uint8_t)(v & 0xFF));  return st;
}

// seq hop le: khac o trong va khong cu hon floor (so sanh vong, chiu duoc tran 16-bit)
static uint8_t seq_valid(uint16_t seq)
{
    return (seq != 0xFFFF) && ((int16_t)(seq - log_floor) >= 0);
}

void log_init(void)
{
    uint16_t f, s;
    uint16_t newest_seq = 0, newest_slot = 0;
    uint8_t  found = 0;
    i2c_status_t st;

    log_ok = 0; log_err = I2C_OK;
    log_cnt = 0; log_floor = 0; log_next_slot = 0; log_next_seq = 0;

    st = rd16(LOG_HDR_ADDR, &f);
    if (st != I2C_OK) { log_err = st; return; }
    log_floor = (f == 0xFFFF) ? 0 : f;

    for (uint16_t i = 0; i < LOG_SLOTS; i++)
    {
        st = rd16(slot_addr(i), &s);
        if (st != I2C_OK) { log_err = st; log_cnt = 0; return; }   // bo cuoc ngay, khong quet tiep
        if (!seq_valid(s)) continue;

        log_cnt++;
        if (!found || (int16_t)(s - newest_seq) > 0)
        {
            newest_seq  = s;
            newest_slot = i;
            found       = 1;
        }
    }

    if (found)
    {
        log_next_slot = (uint16_t)((newest_slot + 1) % LOG_SLOTS);
        log_next_seq  = (uint16_t)(newest_seq + 1);
    }
    else
    {
        log_next_slot = 0;
        log_next_seq  = log_floor;
    }
    if (log_next_seq == 0xFFFF) log_next_seq = 0;

    log_ok = 1;
}

uint16_t log_count(void)
{
    return log_ok ? log_cnt : 0;
}

i2c_status_t log_append(int16_t temp_x10)
{
    uint16_t a;
    i2c_status_t st;

    if (!log_ok)
    {
        log_init();                          // thu khoi tao lai (EEPROM co the vua duoc noi)
        if (!log_ok) return log_err;
    }

    a = slot_addr(log_next_slot);

    // Ghi nhiet do truoc, seq sau cung: ban ghi chi "co hieu luc" khi seq ghi xong.
    // Ghi seq_lo roi moi toi seq_hi de ban ghi do dang (seq_hi con 0xFF) bi loai.
    // Neu co loi giua chung thi KHONG tien con tro: lan sau ghi de len o nay.
    st = eeprom_write_data(a + 2, (uint8_t)((uint16_t)temp_x10 >> 8));    if (st != I2C_OK) return st;
    st = eeprom_write_data(a + 3, (uint8_t)((uint16_t)temp_x10 & 0xFF));  if (st != I2C_OK) return st;
    st = eeprom_write_data(a + 1, (uint8_t)(log_next_seq & 0xFF));        if (st != I2C_OK) return st;
    st = eeprom_write_data(a,     (uint8_t)(log_next_seq >> 8));          if (st != I2C_OK) return st;

    log_next_slot = (uint16_t)((log_next_slot + 1) % LOG_SLOTS);
    log_next_seq++;
    if (log_next_seq == 0xFFFF) log_next_seq = 0;
    if (log_cnt < LOG_SLOTS) log_cnt++;
    return I2C_OK;
}

uint8_t log_get(uint16_t back, int16_t *temp_x10)
{
    uint16_t slot, v;

    if (!log_ok || back >= log_cnt) return 0;

    slot = (uint16_t)((log_next_slot + LOG_SLOTS - 1 - back) % LOG_SLOTS);
    if (rd16(slot_addr(slot) + 2, &v) != I2C_OK) return 0;

    *temp_x10 = (int16_t)v;
    return 1;
}

int16_t log_last_temp(void)
{
    int16_t t = 0;
    if (!log_get(0, &t)) return 0;
    return t;
}

i2c_status_t log_clear(void)
{
    i2c_status_t st;

    if (!log_ok) return log_err;

    // Khong xoa tung o (1 KB x 5 ms = 5 s): chi nang "floor" len seq ke tiep.
    st = wr16(LOG_HDR_ADDR, log_next_seq);
    if (st != I2C_OK) return st;

    log_floor = log_next_seq;
    log_cnt   = 0;
    return I2C_OK;
}
