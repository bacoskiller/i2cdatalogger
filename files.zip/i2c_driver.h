#ifndef I2C_DRIVER_H_
#define I2C_DRIVER_H_

#include <stdint.h>

#ifndef I2C_MODE_MASTER
#define I2C_MODE_MASTER  0
#define I2C_MODE_SLAVE   1
#endif

/* Ma trang thai tra ve */
typedef enum {
    I2C_OK          =  0,
    I2C_ERR_TIMEOUT = -1,   // cho co qua lau
    I2C_ERR_NACK    = -2,   // slave khong ACK (sai dia chi / EEPROM dang ban / cam bien mat ket noi)
    I2C_ERR_BUS     = -3    // loi bus: BERR, ARLO, hoac bus bi ket
} i2c_status_t;

void         i2c_init(void);
void         i2c_recover(void);                 // giai phong bus ket + khoi tao lai I2C1
i2c_status_t i2c_wait_bus_free(void);           // thay cho while (I2C1->SR2 & (1<<1));

i2c_status_t i2c_start(uint8_t mode);
void         i2c_stop(void);
i2c_status_t i2c_send_address(uint8_t address, uint8_t rw);
i2c_status_t i2c_write_data(uint8_t data);
i2c_status_t i2c_write_byte(uint8_t slave_address, uint8_t data);
i2c_status_t i2c_write_mul_bytes(uint8_t slave_address, uint8_t *data, uint8_t length);

/* Doc 1 hoac 2 byte tu slave (do dai khac se tra I2C_ERR_BUS) */
i2c_status_t i2c_read_mul_bytes(uint8_t slave_address, uint8_t *data, uint8_t length);

/* Ghi wlen byte roi Repeated START doc rlen byte (1 hoac 2) - dung cho random read cua EEPROM */
i2c_status_t i2c_write_read(uint8_t slave_address, const uint8_t *wdata, uint8_t wlen,
                            uint8_t *rdata, uint8_t rlen);

#endif
