#ifndef LM75_H
#define LM75_H

#include <stdint.h>

#define LM75_I2C_ADDR  0x48          // 7-bit, A2A1A0 = 000

typedef enum {
    LM75_OK = 0,
    LM75_ERR_NO_RESP,                // khong bao gi: khong ACK / het thoi gian cho
    LM75_ERR_BUS,                    // bao loi: BERR / ARLO tren bus I2C
    LM75_ERR_BAD_VALUE               // tra loi nhung so lieu sai / vo ly
} lm75_status_t;

// Ghi Tos/Thyst (do C, so nguyen duong) va doc lai de xac minh
lm75_status_t LM75_Init(uint8_t tos_c, uint8_t thyst_c);

// Doc nhiet do (don vi 0.1 C) co kiem tra hop le. Chi ghi *temp_x10 khi tra ve LM75_OK
lm75_status_t LM75_ReadTemp(int16_t *temp_x10);

// Bo mau "lan doc truoc" (goi sau khi cam bien hoi phuc / vua cau hinh lai)
void LM75_ResetFilter(void);

#endif
