#include "stm32f10x.h"
#include "i2c_driver.h"
#include "eeprom_i2c.h"
#include "delay.h"

#define EEPROM_RETRY      2      // so lan thu lai giao dich ghi/doc khi loi
#define EEPROM_POLL_MAX   200    // so lan "go cua" toi da khi cho ghi xong
                                 // (moi lan ~ vai tram us -> ~ vai chuc ms >> tWR toi da 10 ms)

/* ACK polling: EEPROM dang ghi noi bo se khong tra ACK (NACK).
 * Lap lai START + SLA+W cho den khi co ACK -> ghi xong.
 * Co gioi han so lan de khong treo neu EEPROM hong / bi rut. */
static i2c_status_t eeprom_wait_standby(void)
{
    for (uint16_t n = 0; n < EEPROM_POLL_MAX; n++)
    {
        i2c_status_t st = i2c_wait_bus_free();
        if (st != I2C_OK) return st;

        st = i2c_start(I2C_MODE_MASTER);
        if (st != I2C_OK) return st;

        st = i2c_send_address(EEPROM_I2C_ADDR, 0);
        if (st == I2C_OK)
        {
            i2c_stop();                  // ACK -> EEPROM da ghi xong, giai phong bus
            return I2C_OK;
        }
        if (st != I2C_ERR_NACK) return st;   // loi bus / timeout that su
        // NACK -> dang ban ghi; i2c_send_address da xoa AF + STOP, thu lai
    }
    return I2C_ERR_TIMEOUT;
}

// GHI 1 BYTE
i2c_status_t eeprom_write_data(uint16_t mem_addr, uint8_t data)
{
    uint8_t buf[3];
    i2c_status_t st = I2C_ERR_TIMEOUT;

    buf[0] = (uint8_t)(mem_addr >> 8);   // dia chi cao
    buf[1] = (uint8_t)(mem_addr & 0xFF); // dia chi thap
    buf[2] = data;

    for (uint8_t n = 0; n < EEPROM_RETRY; n++)
    {
        st = i2c_write_mul_bytes(EEPROM_I2C_ADDR, buf, 3);
        if (st == I2C_OK) break;
    }
    if (st != I2C_OK) return st;

    return eeprom_wait_standby();        // thay cho delay(10)
}

// DOC 1 BYTE: S + SLA+W + addrH + addrL + Sr + SLA+R + data + NACK + P
i2c_status_t eeprom_read_byte(uint16_t mem_addr, uint8_t *data)
{
    uint8_t addr[2];
    uint8_t value = 0;
    i2c_status_t st = I2C_ERR_TIMEOUT;

    addr[0] = (uint8_t)(mem_addr >> 8);
    addr[1] = (uint8_t)(mem_addr & 0xFF);

    for (uint8_t n = 0; n < EEPROM_RETRY; n++)
    {
        st = i2c_write_read(EEPROM_I2C_ADDR, addr, 2, &value, 1);
        if (st == I2C_OK)
        {
            *data = value;
            return I2C_OK;
        }
    }
    return st;
}
